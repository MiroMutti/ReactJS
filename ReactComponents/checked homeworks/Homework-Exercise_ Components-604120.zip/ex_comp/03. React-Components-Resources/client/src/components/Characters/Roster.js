import React from 'react';
import fetcher from '../../fetcher';

const ROSTER_URL = '/roster/';

export default class Rooster extends React.Component {
    constructor(props) {
        super(props)
    }
 
    render = () => {
        const images = this.props.images.map(i => (
            <div key={i.id} className="divSize">
                <img src={i.url} alt="nz"  onClick={() => this.props.select(i.id)} />
            </div>
        ))
        return (
            <section id="roster">
                {images}
            </section>
        )
    }
}